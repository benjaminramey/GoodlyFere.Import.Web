({
    baseUrl: ".",

    paths: {
        "jquery": "empty:"
    },

    name: "main",
    out: "main-built.js"
})
